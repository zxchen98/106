var dialog = document.querySelector('dialog');
console.log(dialog)
function showDialog() {
    console.log('Fired');
    dialog.show();
    setTimeout(function () {
        dialog.close();
      }, 3000);
}